  <aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3   bg-gradient-dark" id="sidenav-main" style="max-width: 20.625rem!important;">
   
      <div class="sidenav-header">
        <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
        <a class="navbar-brand m-0" href=" https://demos.creative-tim.com/material-dashboard/pages/dashboard " target="_blank" style="font-size: 1.2rem;">
        
          <span class="ms-1 font-weight-bold text-white">FUTUREWAY COMPUTER</span>
        </a>
      </div>
  
      <div class="collapse navbar-collapse  w-auto  max-height-vh-150" id="sidenav-collapse-main" style="width:950px;">
        <ul class="navbar-nav" style="width:180px;">
          <li class="nav-item" >
            <a class="nav-link text-white active bg-gradient-primary" >
              <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                <i class="material-icons opacity-10">dashboard</i>
              </div>
              <span >DASHBOARD</a></span>
            </a>
          </li>
          
        </ul>
      </div>
      <div class="sidenav-footer position-absolute w-200 bottom-0 ">
      
  
</div>
    </aside>

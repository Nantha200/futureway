<?php
include "db_connection.php";

if(isset($_POST['submit'])) {
    $invoice_no = isset($_POST['invoice_no']) ? $_POST['invoice_no'] : '';
    $name = $_POST['name'];
    $username = $_POST['username'];
    $status = $_POST['status'];
    $password = password_hash(isset($_POST['password']) ? $_POST['password'] : '', PASSWORD_DEFAULT);
    $id = $_POST['id'];

    $sql = "UPDATE `registration` SET `name`='$name', `username`='$username', `status`='$status' WHERE `id`='$id'";
    $result = $conn->query($sql);

    if ($result === TRUE) {
        echo "Record Updated successfully";
    } 
    else {
        echo "Error: " .  $sql . "<br>" . $conn->error;
    }
}

if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM `registration` WHERE `id`='$id'";
    $result = $conn->query($sql);

    if($result->num_rows > 0) {
        $row = $result->fetch_assoc();
       
        $name = $row['name'];
        $username = $row['username'];
        $status = $row['status']; 
        $id = $row['id'];
    ?>
    <html>
    <body>
        <h2>User Update Form</h2>
        <form action="" method="POST">
          
                <legend>Personal Information</legend>
                <input type="hidden" name="id" value="<?php echo $id; ?>">
               
                Name:<br>
                <input type="text" name="name" value="<?php echo $name; ?>">
                <br>
                Address:<br>
                <input type="text" name="username" value="<?php echo $username; ?>" readonly>
                <br>
               
                <label class="role">ROLE</label>
                <select id="status" name="status" class="option" style="margin-left:75px">
                    <option value="panding" <?php if($status == 'panding') echo 'selected'; ?>>panding</option>
                    <option value="ongoing" <?php if($status == 'ongoing') echo 'selected'; ?>>ongoing</option>
                    <option value="complete" <?php if($status == 'complete') echo 'selected'; ?>>complete</option>
                </select>     
                <input type="submit" name="submit" value="Submit">
      
        </form>
    </body>
    </html>
    <?php
    } else {
        // If the 'id' value is not valid, redirect the user back to view.php page
        header("location:view.php");
    }
}

?>

<footer class="footer pt-5">
      <div class="container-fluid">
        <div class="row align-items-center justify-content-lg-between">
          <div class="col-lg-6 mb-lg-0 mb-4">
           
          </div>
          <div class="col-lg-12">
            <ul class="nav nav-footer justify-content-center justify-content-lg-end">
              <li class="nav-item">
                <a href="#" class="nav-link text-muted" target="_blank">ABOUT US</a>
              </li>
              <li class="nav-item">
                <a href="#" class="nav-link text-muted" target="_blank">SERVICES</a>
              </li>
              <li class="nav-item">
                <a href="#" class="nav-link text-muted" target="_blank">CONTACT</a>
              </li>
           
             
            </ul>
          </div>
        </div>
      </div>
    </footer>

</main>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/perfect-scrollbar.min.js"></script>
  <script src="../assets/js/smooth-scrollbar.min.js"></script>
</body>
</html>
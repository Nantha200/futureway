<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

include 'db_connection.php';

$username = $_SESSION['username'];


$userSql = "SELECT * FROM user WHERE username = '$username'";
$userResult = $conn->query($userSql);

if ($userResult->num_rows > 0) {
    $userRow = $userResult->fetch_assoc();
 
} else {
    echo "user not found in the user table.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Superuser Dashboard</title>
</head>
<body>
    <h1>Welcome to the user Dashboard</h1>
    <p>Username: <?php echo $username; ?></p>
   
    <a href="logout.php">Logout</a> 
</body>
</html>

